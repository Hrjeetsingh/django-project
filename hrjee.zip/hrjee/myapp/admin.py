from django.contrib import admin
from .models import Insertmarks
from .models import QUS_ANS

# Register your models here.
admin.site.register(Insertmarks)
admin.site.register(QUS_ANS)
admin.site.site_header='hrjeet0987@gmail.com'
admin.site.index_title='Welcome to Singh Portal'
