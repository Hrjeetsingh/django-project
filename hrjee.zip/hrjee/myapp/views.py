from django.shortcuts import render
from django.http import HttpResponse
from . models import Insertmarks
from . models import QUS_ANS
# Create your views here.
def demo(r):
    data=Insertmarks.objects.all()
    params={'da':data}
    return render(r,'HOME.html',params)
def CPROG(r):
    data=QUS_ANS.objects.all()
    params={'da':data}
    return render(r,'c.html',params)
def JAVA(r):
    data=QUS_ANS.objects.all()
    params={'da':data}
    return render(r,'JAVA.html',params)
def PYTHON(r):
    data=QUS_ANS.objects.all()
    params={'da':data}
    return render(r,'PYTHON.html',params)
def CPP(r):
    data=QUS_ANS.objects.all()
    params={'da':data}
    return render(r,'C++.html',params)
def CONTECT(r):
    data=QUS_ANS.objects.all()
    params={'da':data}
    return render(r,'CONTECT.html',params)
def ABOUT(r):
    data=QUS_ANS.objects.all()
    params={'da':data}
    return render(r,'ABOUT.html',params)