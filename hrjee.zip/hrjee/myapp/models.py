from django.db import models

# Create your models here.
class Insertmarks(models.Model):
    URNO=models.IntegerField()
    UNAME=models.CharField(max_length=30)
    URPHY=models.IntegerField()
    UCHE=models.IntegerField()
    UMATHS=models.IntegerField()
    def __str__(self):
        return str(self.URNO)

class QUS_ANS(models.Model):
    la=(('J','JAVA'),('P','PYTHON'),('C','C prog..'),('C+','C++ prog..'))
    lang=models.CharField(max_length=10,choices=la)        
    question=models.CharField(max_length=300)
    answer=models.TextField()
    def __str__(self):
        return self.question