
from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('', views.demo,name='HOME'),
    path('CPROG/', views.CPROG,name='CPROG'),
    path('JAVA/', views.JAVA,name='JAVA'),
    path('PYTHON/', views.PYTHON,name='PYTHON'),
    path('CPP/', views.CPP,name='CPP'),
    path('CONTECT/', views.CONTECT,name='CONTECT'),
    path('ABOUT/', views.ABOUT,name='ABOUT')
]
